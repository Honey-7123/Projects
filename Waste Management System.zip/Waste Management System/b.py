from fastapi import FastAPI
app=FastAPI()
@app.get("/")
def read():
    return{"message":"hello"}
@app.get("/hi")
def read():
    return {"message":"hello"}